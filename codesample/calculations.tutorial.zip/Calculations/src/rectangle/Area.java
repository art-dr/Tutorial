package rectangle;

public class Area {
    public static void main(String[] args) {
        int width = 5.4
        int leength = 4.6
        int area = width * length;

        System.out.println("The area of a rectangle is " + area + " square meters.");

    }
}